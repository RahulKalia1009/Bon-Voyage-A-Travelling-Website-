import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import './hotel.css';
import Form from 'react-bootstrap/Form';
import { Button } from 'react-bootstrap';
import { useRef } from "react";
import {useNavigate} from "react-router-dom";

function Hotel() {
    const location = useLocation();
    const ref = useRef();
    const navigate = useNavigate();
    const daata = location.state;
    // console.log(daata);
    const [Hotel, setHotel] = useState([]);
    const [Loading, setLoading] = useState(true);

    const getData = async (e) => {
        const aa = daata;
        const optionss = {
            method: 'GET',
            url: 'https://booking-com.p.rapidapi.com/v1/hotels/search',
            params: {
                checkin_date: '2023-11-27',
                dest_type: 'city',
                units: 'metric',
                checkout_date: '2023-11-28',
                adults_number: '2',
                order_by: 'popularity',
                dest_id: aa,
                filter_by_currency: 'INR',
                locale: 'en-us',
                room_number: '1',
                children_number: '2',
                children_ages: '5,0',
                categories_filter_ids: 'class::2,class::4,free_cancellation::1',
                page_number: '0',
                include_adjacency: 'true'
            },
            headers: {
                'X-RapidAPI-Key': '65f0da8824msh08c2a23f8bdc210p110350jsn360aa620e69b',
                'X-RapidAPI-Host': 'booking-com.p.rapidapi.com'
            }
        };

        try {
            const responsee = await axios.request(optionss);
            console.log(responsee.data)
            setHotel(responsee.data.result)
            setLoading(false);
        } catch (error) {
            console.error(error);
        }

    }
    useEffect(() => {
        getData();
    }, [])
    if (Loading === false) {
        console.log(Hotel)
        const handleHotel = async (e) => {
            e.preventDefault();
            e.stopPropagation();
    
            const a = ref.current.value;
            console.log(a)
            navigate("/Hotelinfo", {state: Hotel[0]});
        }
        return (
            <>
                <p>hello</p>
                <div className="row row-cols-1 row-cols-md-2 g-4 w-75  ">

                    {Hotel.map((item) => {
                        return (
                            <div className="card">
                                <div className="col">
                                    <img src={item.max_1440_photo_url} className="card-img-top  " alt="..."></img>
                                    <div className="card-body">
                                        <h4 className="card-title">{item.hotel_name}</h4>
                                        <p className="card-text">{item.address},{item.city}</p>
                                        <h5>{item.min_total_price} INR</h5>
                                        <Form onSubmit={handleHotel}>
                                            <Form.Control type='text' ref={ref} name='toez' value={item.hotel_id} hidden></Form.Control>
                                            <Button id='eee' type='submit'  >Book</Button>
                                        </Form>
                                    </div>
                                </div>
                            </div>
                        )
                    })}

                </div>

            </>
        )
    }
  

    return (
        <>
            {Loading ? <p>Loading...</p> : null}
        </>
    )
}

export default Hotel